"""Register this ITP checkout in Claude Code without changing tracked files."""

import json
from pathlib import Path
import stat
import tomllib


ROOT = Path(__file__).resolve().parent
SKILLS = ROOT / ".agents" / "skills"
AGENTS = ROOT / ".codex" / "agents"
ARTIFACT_ROLES = {"intent_realizer", "product_contract_agent", "independent_verifier"}
CLAUDE_MD = """@AGENTS.md
@tools/intent-tool-pipeline/AGENTS.md

## Claude Code on Windows

Start at this repository root. Read additional nested AGENTS.md files for the
workspaces you use. Invoke project skills with /<skill-name>. During execution,
resolve ITP skill references from the corresponding original .agents/skills/
file. Use the repository .venv and the tool project root defined in AGENTS.md.
Use the destination's Claude model and effort settings in place of Codex-specific
model, effort and tool names. Use Claude's Agent tool for required delegation
from Root. Preserve all role IDs, approved write scopes, independent verification,
and procedure binding. Role registration alone does not start an ITP workflow.
"""


def agent_definition(source: Path) -> tuple[str, bytes]:
    data = tomllib.loads(source.read_text(encoding="utf-8"))
    name = data["name"]
    tools = "Read, Glob, Grep"
    if name in ARTIFACT_ROLES:
        tools += ", Write, Bash, PowerShell"
    definition = (
        "---\n"
        f"name: {json.dumps(name)}\n"
        f"description: {json.dumps(data['description'], ensure_ascii=False)}\n"
        f"tools: {tools}\n"
        "disallowedTools: Agent\n"
        "permissionMode: default\n"
        "---\n"
        f"{data['developer_instructions']}"
    )
    return name, definition.encode("utf-8")


def check_destination(path: Path, content: bytes) -> None:
    # Check every component so an existing Windows junction also stops setup.
    for item in reversed([path, *path.parents][:len(path.relative_to(ROOT).parts)]):
        try:
            metadata = item.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(metadata.st_mode) or (
            getattr(metadata, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT
        ):
            raise SystemExit(f"Setup stopped at a link or reparse point: {item.relative_to(ROOT)}")
        if item != path and not stat.S_ISDIR(metadata.st_mode):
            raise SystemExit(f"Setup needs a directory at: {item.relative_to(ROOT)}")
    if path.exists() and (not path.is_file() or path.read_bytes() != content):
        raise SystemExit(f"Setup would replace an existing file: {path.relative_to(ROOT)}")


def main() -> None:
    claude = ROOT / ".claude"
    skills = sorted(path.parent for path in SKILLS.glob("*/SKILL.md"))
    agents = sorted(AGENTS.glob("*.toml"))
    if not skills or not agents:
        raise SystemExit("Run setup from an extracted ITP repository containing .agents and .codex.")

    files = {ROOT / "CLAUDE.md": CLAUDE_MD.encode("utf-8")}
    # build-tool-pipeline/SKILL.md references this file two directories above itself.
    files[claude / "delegation-policy.md"] = (SKILLS.parent / "delegation-policy.md").read_bytes()
    for skill in skills:
        for source in sorted(skill.rglob("*")):
            relative = source.relative_to(SKILLS)
            if source.is_file() and "__pycache__" not in relative.parts and source.suffix != ".pyc":
                files[claude / "skills" / relative] = source.read_bytes()
    for source in agents:
        name, content = agent_definition(source)
        files[claude / "agents" / f"{name}.md"] = content

    for path, content in files.items():
        check_destination(path, content)
    for path, content in files.items():
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("xb") as target:
                target.write(content)
    print(f"Claude registration ready: {len(skills)} skills, {len(agents)} custom agents.")


if __name__ == "__main__":
    main()
